/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package xadrex;

/**
 *
 * @author Admin
 */
public class Peao extends Peca {
    
    @Override
    public void mover(){
        System.out.println("ANDAR PARA FRENTE");
    }
    
}
